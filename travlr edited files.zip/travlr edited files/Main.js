from user_preferences import get_user_preferences
from recommendations import generate_recommendations
from display import display_recommendations

def main():
    user_preferences = get_user_preferences()
    recommendations = generate_recommendations(user_preferences)
    display_recommendations(recommendations)

if __name__ == "__main__":
    main()
def generate_recommendations(user_preferences):
    travel_database = [
        {"destination": "Hawaii", "interests": ["Adventure", "Relaxation"], "budget": "High"},
        {"destination": "Paris", "interests": ["Culture"], "budget": "Medium"},
        {"destination": "Thailand", "interests": ["Adventure", "Culture"], "budget": "Low"},
        # Add more destinations as needed
    ]

    recommendations = []
    for trip in travel_database:
        if trip['budget'] == user_preferences['budget'] and any(interest in trip['interests'] for interest in user_preferences['interests'].split(',')):
            recommendations.append(trip['destination'])

    return recommendations
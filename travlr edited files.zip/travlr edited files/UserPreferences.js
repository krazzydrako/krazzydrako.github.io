def get_user_preferences():
    print("Please answer the following questions to get your travel recommendations:")
    preferences = {}
    preferences['budget'] = input("What is your budget? (e.g., Low, Medium, High): ")
    preferences['interests'] = input("What activities do you enjoy? (e.g., Adventure, Relaxation, Culture): ")
    preferences['past_trips'] = input("Where have you traveled before? (comma-separated): ").split(',')
    return preferences
def display_recommendations(recommendations):
    if recommendations:
        print("Based on your preferences, we recommend the following destinations:")
        for destination in recommendations:
            print(f"- {destination}")
    else:
        print("No recommendations found based on your preferences.")